from django.shortcuts import render, redirect
from .models import Post, Comment
from .forms import CommentForm 


def home(request):
    return render(request, 'home.html')


def post_detail(request, post_id):
    post = Post.objects.get(id=post_id)
    comments = post.comments.all().order_by('-created_at')

    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.post = post
            comment.user = request.user
            comment.save()
            return redirect('post_detail', post_id=post.id)
    else:
        form = CommentForm()

    return render(request, 'post_detail.html', {'post': post, 'comments': comments, 'form': form})
